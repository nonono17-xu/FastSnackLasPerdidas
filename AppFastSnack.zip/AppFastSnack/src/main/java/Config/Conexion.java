/*

* Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license

* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template

*/

package Config;
 
import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.SQLException;

import modelo.utilidades.DAOException;
 
/**

*

* @author fl1pc12

*/

public class Conexion {
 
    private static Conexion instancia;

    private Connection conexion;

    private final String url = "jdbc:mysql://localhost:3306/FastSnackbd";

    private final String user = "root";

    private final String password = "";
 
    private Conexion() {

    try {

        Class.forName("com.mysql.cj.jdbc.Driver");

        conexion = (Connection) DriverManager.getConnection(url, user, password);

        System.out.println("Conexion exitosa");

    } catch (ClassNotFoundException | SQLException error) {

        System.out.println("ERROR DE CONEXION" + error.getMessage());

    }

}
 
    //Metodo para establecer una instancia unica

    public static synchronized Conexion getInstance() throws DAOException {

        if (instancia == null) {

            instancia = new Conexion();

        }

        return instancia;

    }

   //metodo publico de tipo conexion

    public Connection getConnection() throws DAOException{

    try{

        if(conexion == null || conexion.isClosed()){

        conexion = DriverManager.getConnection(url, user, password);

        }

        return conexion;

    } catch(SQLException error){

    throw new DAOException("No se puedo", error);

        }

    }

    //Metodo para cerrar conexiones

    public void CloseConexion() throws SQLException{

     if(conexion != null && !conexion.isClosed()){}

        conexion.close();

        instancia = null;

    }

}
 
 
 