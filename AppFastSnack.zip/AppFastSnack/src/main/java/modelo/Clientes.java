/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
 
/**
 *
 * @author fl1pc12
 */
public  class Clientes extends Persona {
 
    private String direccion;
 
    public Clientes(String direccion, String telefono, String nombre) {
        super(nombre, telefono);
        this.direccion = direccion;
    }
//Metodos de acceso
    public String getDireccion() {
        return direccion;
    }
 
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
 
    @Override
    void accederCliente() {
 
    }
    @Override
    public String getNombre() {
        return super.getNombre();
}
 
}