/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package modelo;

/**
 *
 * @author Jordy
 */
public class InterfaceOpinion extends javax.swing.JFrame {

    private String calificacionSeleccionada = "";

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(InterfaceOpinion.class.getName());

    public InterfaceOpinion() {
        initComponents();
        this.setLocationRelativeTo(null);
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnExcelente = new javax.swing.JButton();
        btnBueno = new javax.swing.JButton();
        btnRegular = new javax.swing.JButton();
        btnMalo = new javax.swing.JButton();
        btnMuyMalo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtComentario = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        btnEnviar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Sylfaen", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 153));
        jLabel1.setText("QUEREMOS SABER TU OPINION DEL SERVICIO");
        jLabel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel1.setOpaque(true);

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 51, 204));
        jLabel2.setText("¿COMÓ FUE TU EXPERIENCIA EL DIA DE HOY?");
        jLabel2.setOpaque(true);

        btnExcelente.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnExcelente.setForeground(new java.awt.Color(255, 102, 255));
        btnExcelente.setText("EXCELENTE ");
        btnExcelente.addActionListener(this::btnExcelenteActionPerformed);

        btnBueno.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnBueno.setForeground(new java.awt.Color(255, 153, 204));
        btnBueno.setText("BUENO");
        btnBueno.addActionListener(this::btnBuenoActionPerformed);

        btnRegular.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnRegular.setForeground(new java.awt.Color(255, 181, 181));
        btnRegular.setText("REGULAR");
        btnRegular.addActionListener(this::btnRegularActionPerformed);

        btnMalo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnMalo.setForeground(new java.awt.Color(255, 102, 102));
        btnMalo.setText("MALO");
        btnMalo.addActionListener(this::btnMaloActionPerformed);

        btnMuyMalo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnMuyMalo.setForeground(new java.awt.Color(255, 51, 51));
        btnMuyMalo.setText("MUY MALO");
        btnMuyMalo.addActionListener(this::btnMuyMaloActionPerformed);

        txtComentario.setColumns(20);
        txtComentario.setRows(5);
        jScrollPane1.setViewportView(txtComentario);

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Segoe UI Emoji", 2, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 0, 153));
        jLabel3.setText("DÉJANOS TU COMENTARIO:");
        jLabel3.setOpaque(true);

        btnEnviar.setForeground(new java.awt.Color(255, 0, 204));
        btnEnviar.setText("ENVIAR OPINIÓN");
        btnEnviar.addActionListener(this::btnEnviarActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(163, 163, 163)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(227, 227, 227)
                        .addComponent(jLabel2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(btnEnviar))
                            .addComponent(jScrollPane1)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(btnExcelente)
                                .addGap(61, 61, 61)
                                .addComponent(btnBueno)
                                .addGap(81, 81, 81)
                                .addComponent(btnRegular)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                                .addComponent(btnMalo)
                                .addGap(48, 48, 48)
                                .addComponent(btnMuyMalo)))
                        .addGap(74, 74, 74))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(68, 68, 68)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnExcelente)
                    .addComponent(btnBueno)
                    .addComponent(btnRegular)
                    .addComponent(btnMalo)
                    .addComponent(btnMuyMalo))
                .addGap(49, 49, 49)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnEnviar)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnExcelenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcelenteActionPerformed
        calificacionSeleccionada = "EXCELENTE";
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccionaste: EXCELENTE");
    }//GEN-LAST:event_btnExcelenteActionPerformed

    private void btnRegularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegularActionPerformed
        calificacionSeleccionada = "REGULAR";
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccionaste: REGULAR");
    }//GEN-LAST:event_btnRegularActionPerformed

    private void btnMaloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMaloActionPerformed
        calificacionSeleccionada = "MALO";
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccionaste: MALO");
    }//GEN-LAST:event_btnMaloActionPerformed

    private void btnMuyMaloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMuyMaloActionPerformed
        calificacionSeleccionada = "MUY MALO";
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccionaste: MUY MALO");
    }//GEN-LAST:event_btnMuyMaloActionPerformed

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarActionPerformed
        if (calificacionSeleccionada.equals("")) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Por favor, selecciona una calificación antes de enviar tu opinión.",
                    "Atención",
                    javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        String comentario = txtComentario.getText().trim();

        String mensajeExito = "¡Gracias por tu opinión!\n"
                + "Calificación: " + calificacionSeleccionada + "\n"
                + "Comentario: " + (comentario.isEmpty() ? "Ninguno" : comentario);

        javax.swing.JOptionPane.showMessageDialog(this,
                mensajeExito,
                "Encuesta Guardada",
                javax.swing.JOptionPane.INFORMATION_MESSAGE);

        calificacionSeleccionada = "";
        txtComentario.setText("");
        Interfaz_Bienvenida regresar = new Interfaz_Bienvenida();
        regresar.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnEnviarActionPerformed

    private void btnBuenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuenoActionPerformed

        calificacionSeleccionada = "Bueno";
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccionaste: BUENO");

    }//GEN-LAST:event_btnBuenoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new InterfaceOpinion().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBueno;
    private javax.swing.JButton btnEnviar;
    private javax.swing.JButton btnExcelente;
    private javax.swing.JButton btnMalo;
    private javax.swing.JButton btnMuyMalo;
    private javax.swing.JButton btnRegular;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txtComentario;
    // End of variables declaration//GEN-END:variables
}
