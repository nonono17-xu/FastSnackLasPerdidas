/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Config.*;
import java.util.Optional;
import modelo.Clientes;
import modelo.utilidades.DAOException;


public class ClienteDAOImpl implements ClienteDAO {
    private static ClienteDAOImpl instance;
    
    private final Conexion conexion;

    public ClienteDAOImpl() throws DAOException {
        this.conexion=Conexion.getInstance();
    }
    
    
    
    @Override
    public Optional<Clientes> findByName(String nombre) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean existByPhone(String telefono) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
